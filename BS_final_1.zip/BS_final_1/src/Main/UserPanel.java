package Main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import SPIRE.FetchPolicy;
import SPIRE.FetchSecret;
import SPIRE.Preprocess;
import SPIRE.SynGrd;


public class UserPanel extends JPanel implements ActionListener,Observer{
	private static final long serialVersionUID = 1L;
	
	Main parent;
	JButton ret;
	JButton exec;
	
	String DataBase=new String();
	String Table=new String();
	String Col = new String();
	String Value = new String();
	String Pass = new String();
	String user = new String();
	
	JComboBox<String> DBs;
	JLabel db;
	JComboBox<String> tables;
	JLabel tbl;
	JComboBox<String> cols;
	JLabel column;
	
	JTextField query;
	JComboBox<String> values;
	JLabel q;

	private Image backGround;
	private Observable obs;
	
	public UserPanel(Main parent) {
		
		setLayout(null);
		this.parent = parent;
		obs = new Observable();
		obs.addObserver(this);

		
		db = new JLabel("select the DataBase");
		db.setFont(new Font("Times New Roman",70,30));
		db.setForeground(Color.WHITE);
		db.setSize(new Dimension(300,40));
		db.setLocation(200, 50);
		this.add(db);
		
		DBs = new JComboBox<String>();
		DBs.setSize(new Dimension(300,40));
		DBs.setLocation(500, 50);
		updateList();
		DBs.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				DataBase = DBs.getSelectedItem().toString().trim();
				update(obs, 1);
			}
		});
		
		this.add(DBs);
		
		tbl = new JLabel("select the Table");
		tbl.setFont(new Font("Times New Roman",70,30));
		tbl.setForeground(Color.WHITE);
		tbl.setSize(new Dimension(300,40));
		tbl.setLocation(200, 120);
		this.add(tbl);
		
		tables = new JComboBox<String>();
		tables.setSize(new Dimension(300,40));
		tables.setLocation(500, 120);
		tables.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				Table = tables.getSelectedItem().toString().trim();
				update(obs, 2);
			}
		});
		this.add(tables);
		
		column = new JLabel("select the columns");
		column.setFont(new Font("Times New Roman",70,30));
		column.setForeground(Color.WHITE);
		column.setSize(new Dimension(300,40));
		column.setLocation(200, 190);
		this.add(column);
		
		cols = new JComboBox<String>();
		cols.setSize(new Dimension(300,40));
		cols.setLocation(500, 190);
		cols.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(cols.getItemCount() > 0)
					Col = cols.getSelectedItem().toString().trim();
				update(obs, 3);
			}
		});
		this.add(cols);
		
		
		q = new JLabel("column value");
		q.setFont(new Font("Times New Roman",70,30));
		q.setForeground(Color.WHITE);
		q.setSize(new Dimension(300,40));
		q.setLocation(200, 260);
		this.add(q);
		
//		query =new JTextField();
//		query.setSize(new Dimension(600,100));
//		query.setLocation(220, 300);
//		query.setEditable(true);
//		this.add(query);
		
		values = new JComboBox<String>();
		values.setSize(new Dimension(300,40));
		values.setLocation(500, 260);
		values.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(values.getItemCount() > 0)
					Value = values.getSelectedItem().toString().trim();
				update(obs, 4);
			}
		});
		this.add(values);
	
		exec = new JButton("execute");
		exec.setFont(new Font("Times New Roman" , 30,30));
        exec.setIcon(new ImageIcon("../welcome/exec_button.png"));
		exec.setSize(200,50);
		exec.setLocation(300, 450);
		exec.addActionListener(this);
		this.add(exec);
		
		
		ret = new JButton("return");
		ret.setFont(new Font("Times New Roman" , 30,30));
        ret.setIcon(new ImageIcon("../welcome/ret_button.png"));
		ret.setSize(200, 50);
		ret.setLocation(600, 450);
		ret.addActionListener(this);
		this.add(ret);
		
        this.setBackGroundImage(new ImageIcon("../welcome/Main_back.jpg").getImage());

		
	}
	
	
    @Override
   protected void paintComponent(Graphics g) {

         // get the size of this panel (which is the size of the applet),
         // and draw the image
   	 super.paintComponent(g);
         g.drawImage(getBackGroundImage(), 0, 0,
             (int)getBounds().getWidth(), (int)getBounds().getHeight(), this);
    }

    public void setBackGroundImage(Image backGround) {
         this.backGround = backGround; 
    }

    private Image getBackGroundImage() {
         return backGround;    
    }

	
	
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == ret){
			this.setVisible(false);
			this.parent.returned();
		}
		else if(e.getSource() == exec){
			executeQuery();
			//System.out.println(DataBase+" "+user+" "+Pass+" "+Table+" "+ Col+ " "+ Value);
		}
	}

	//update the db list in combo box
	private void updateList(){
		Vector<String> list = new Vector<String>();
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/BSAdminUsers","root","0019119275");  
			Statement stmt=con.createStatement();  
			ResultSet rs=stmt.executeQuery("select DB_name from DBs");  
			while(rs.next())
				list.add(rs.getString(1));
			con.close();  
			DBs.removeAllItems();
			for(String v: list)
				DBs.addItem(v);
			}catch(Exception e1){
				String[] s = e1.toString().trim().split(":");
				JOptionPane.showMessageDialog(null, s[1]);}
	}


	//update the fields according to db and table selected
	@Override
	public void update(Observable obs, Object obj) {
		if(obj.equals(1)){
			try{  
				Class.forName("com.mysql.jdbc.Driver");  
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/BSAdminUsers","root","0019119275");  
				Statement stmt=con.createStatement();  
				ResultSet rs=stmt.executeQuery("select * from DBs where DB_name =\'"+DataBase+"\'");  
				if(rs.next())
				{
					user= rs.getString(2).trim();
					Pass= rs.getString(3).trim();
				}
				con.close();  
				Vector<String> list = new Vector<String>();
				try{  
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con2=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DataBase,user,Pass);  
					Statement stmt2=con2.createStatement();  
					ResultSet rs2=stmt2.executeQuery("show tables");  
					while(rs2.next())
						if(rs2.getString(1).compareTo("policy")!=0)
							list.add(rs2.getString(1));
					con2.close();  
					tables.removeAllItems();
					for(String v: list)
						tables.addItem(v);
					}catch(Exception e1){
						String[] s = e1.toString().trim().split(":");
						JOptionPane.showMessageDialog(null, s[1]);}
				
				}catch(Exception e1){
					String[] s = e1.toString().trim().split(":");
					JOptionPane.showMessageDialog(null, s[1]);}
			
			}
		else if(obj.equals(2)){
			Vector<String> list = new Vector<String>();
			try{  
				Class.forName("com.mysql.jdbc.Driver");  
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DataBase,user,Pass); 
				Statement stmt=con.createStatement();  
				ResultSet rs=stmt.executeQuery("select * from " +Table);  
				ResultSetMetaData rsmd = rs.getMetaData();
				int colcount = rsmd.getColumnCount();
				if(rs.next()){
				for(int i = 1; i<= colcount ; i++)
					if(rsmd.getColumnName(i).trim().compareTo("ID") != 0 )
						list.add( rsmd.getColumnName(i).trim());
				}
				con.close(); 
//				list=list.substring(0, list.length()-2);
//				cols.setText(list);
				}catch(Exception e1){
					//String[] s = e1.toString().trim().split(":");
					System.out.println(e1);
					JOptionPane.showMessageDialog(null, e1);}
			cols.removeAllItems();
			for (String s : list) {
				cols.addItem(s);
			}
		}
		else if(obj.equals(3)){
			System.out.println("here");
			try{  
				Class.forName("com.mysql.jdbc.Driver");  
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DataBase,user,Pass);  
				Statement stmt=con.createStatement();  
				ResultSet rs=stmt.executeQuery("select "+Col+" from " +Table +" where ID=1");  
				values.removeAllItems();
				if(rs.next()){
					Object[] str = rs.getString(1).trim().split(",");
					for(int k =0 ; k<str.length ; k++){
						values.addItem(str[k].toString());
					}
				}
				con.close(); 
//				list=list.substring(0, list.length()-2);
//				cols.setText(list);
				}catch(Exception e1){
					String[] s = e1.toString().trim().split(":");
					JOptionPane.showMessageDialog(null, s[1]);}
		}
	}
	
	private void executeQuery(){
		FetchSecret fs = new FetchSecret(DataBase,user,Pass,Table, Col, Value);
		FetchPolicy fp = new FetchPolicy(DataBase,user,Pass,Table, Col);
		Preprocess pre = new Preprocess(fs.getValues(), fs.getTotal(), fs.getValue(), fp.getPolicies());
		SynGrd sg = new SynGrd("precision", pre);
		int resCls = sg.getC().elementAt(fs.getResult());
		int count = 0 ; 
		for(int i = 0  ; i<sg.getC().size() ; i++){
			if(sg.getC().elementAt(i) == resCls){
				count++;
			}
		}
		double prob = ((double)1)/((double)count);
		String str = "There are "+fs.getResult()+ " records of desired value in the table and the probability of the answer is "+prob;
		JOptionPane.showMessageDialog(null, str);
		System.out.println(sg.getC().elementAt(fs.getResult()) +"   "+ fs.getResult());
	}
	
}