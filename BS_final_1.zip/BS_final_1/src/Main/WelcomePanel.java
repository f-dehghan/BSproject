package Main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class WelcomePanel extends JPanel implements ActionListener {

		private static final long serialVersionUID = 1L;

		
		 Main parent;
		 Image backGround;
		 JLabel users;
	     JButton admin;
	     JButton user;
	     
	     Image bgImage;
	     
	     public WelcomePanel(Main parent) {
	    	 setLayout(null);
	    	 this.parent=parent;
//	    	 Frame frame = (Frame)this.parent.getParent().getParent();
//	    	 Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
//	    	 int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
//	    	 int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);

	          users = new JLabel();
	          users.setFont(new Font("Times New Roman", 50, 50));
	          users.setSize(400,100);
	          users.setIcon(new ImageIcon("../welcome/users_label.png"));
	          users.setForeground(Color.white);
	          users.setBackground(Color.BLACK);
	          users.setLocation(150,100);
	          this.add(users);

	          //Admin Button
	          admin = new JButton("ADMIN");
	          admin.setFont(new Font("Times New Roman", 50,50));
	          admin.setIcon(new ImageIcon("../welcome/admin_button.png"));
	          admin.setSize(300,100);
	          admin.setLocation(400, 400);
	          admin.addActionListener(this);
	          this.add(admin);
	          
	          //User Button
	          user = new JButton("USER");
	          user.setFont(new Font("Times New Roman", 50,50));
	          user.setIcon(new ImageIcon("../welcome/user_button.png"));
	          user.setSize(300,100);
	          user.setLocation(400, 250);
	          user.addActionListener(this);
	          this.add(user);
	          
	          this.setBackGroundImage(new ImageIcon("../welcome/Main_back.jpg").getImage());
	          this.setVisible(true);
	     }

	     @Override
	    protected void paintComponent(Graphics g) {
	 
	          // get the size of this panel (which is the size of the applet),
	          // and draw the image
	    	 super.paintComponent(g);
	          g.drawImage(getBackGroundImage(), 0, 0,
	              (int)getBounds().getWidth(), (int)getBounds().getHeight(), this);
	     }

	     public void setBackGroundImage(Image backGround) {
	          this.backGround = backGround; 
	     }

	     private Image getBackGroundImage() {
	          return backGround;    
	     }

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			this.setVisible(false);
			
			if(e.getSource() == admin){
				this.parent.userType(1);
			}
			else if(e.getSource() == user){
				this.parent.userType(2);
			}
			
		}
	
	}