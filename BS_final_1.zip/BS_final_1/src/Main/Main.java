package Main;

import java.awt.*;

import javax.swing.JApplet;



public class Main extends JApplet  {

	private static final long serialVersionUID = 1L;

	WelcomePanel bgp;
	 
     
     public void init() {
    	  setLayout(null);
    	 //set title of the window and it's location on the screen 
    	 Frame frame = (Frame)this.getParent().getParent();
    	 frame.setTitle("DataBse Security");
    	 Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
    	 int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
    	 int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
    	 frame.setLocation(x, y);
    	 frame.setResizable(false);
    	
    	 
          bgp = new WelcomePanel(this);        
        
          
          bgp.setBounds(0, 0, 1000, 600);
          bgp.setSize(1000,600);
          this.add(bgp);
         
     }
     
     
     public void userType(int type){
    	 this.remove(bgp);
    	 if(type == 1){ // admin user 
    		 AdminPanel ap = new AdminPanel(this);
    		 ap.setBounds(0, 0, 1000, 600);
    		this.add(ap);
//    		 DBManage();
    	 }
    	 else if(type == 2){ // typical user
    		 UserPanel up = new UserPanel(this);
    		 up.setBounds(0, 0, 1000, 600);
    		 this.add(up);
    	 }
     }
     
     public void returned(){
    	 bgp = new WelcomePanel(this);
    	 bgp.setBounds(0, 0, 1000, 600);
    	 this.add(bgp);
     }
     
     public void DBManage(){
    	 dataBase.DBManage dbm = new dataBase.DBManage(this);
    	 dbm.setBounds(0, 0, 1000, 600);
    	 this.add(dbm);
     }
}
