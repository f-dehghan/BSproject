package Main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AdminPanel extends JPanel implements ActionListener{
	private static final long serialVersionUID = 1L;
	
	Main parent;
	 Image backGround;
	JButton ret;
	JButton ok;
	
	JLabel userL;
	JLabel passL;
	
	JTextField username;
	JTextField password;
	
	
	public AdminPanel(Main parent) {
		
		this.setLayout(null);
		
		this.parent = parent;
		
		userL = new JLabel("user name:");
		userL.setFont(new Font("Times New Roman" , 30,30));
		userL.setForeground(Color.WHITE);
		userL.setSize(150,50);
		userL.setLocation(300, 50);
		this.add(userL);
		
		
		passL = new JLabel("password:");
		passL.setFont(new Font("Times New Roman" , 30,30));
		passL.setForeground(Color.WHITE);
		passL.setSize(150,50);
		passL.setLocation(300, 150);
		this.add(passL);
		
		
		username = new JTextField();
		username.setFont(new Font("Times New Roman" , 30,30));
		username.setSize(200,50);
		username.setEditable(true);
		username.setLocation(500, 50);
		this.add(username);
		
		//JOptionPane.shoI
		password = new JTextField();
		password.setFont(new Font("Times New Roman" , 30,30));
		password.setSize(200,50);
		password.setEditable(true);
		password.setLocation(500, 150);
		this.add(password);
		
		ok = new JButton("OK");
		ok.setFont(new Font("Times New Roman" , 30,30));
        ok.setIcon(new ImageIcon("../welcome/ok_button.png"));
		ok.setSize(200,50);
		ok.setLocation(400, 250);
		ok.addActionListener(this);
		this.add(ok);
		
		
		ret = new JButton("return");
		ret.setFont(new Font("Times New Roman" , 30,30));
        ret.setIcon(new ImageIcon("../welcome/ret_button.png"));
		ret.setSize(200,50);
		ret.setLocation(400, 350);
		ret.addActionListener(this);
		this.add(ret);
		
        this.setBackGroundImage(new ImageIcon("../welcome/Main_back.jpg").getImage());

	}
	

    @Override
   protected void paintComponent(Graphics g) {

         // get the size of this panel (which is the size of the applet),
         // and draw the image
   	 super.paintComponent(g);
         g.drawImage(getBackGroundImage(), 0, 0,
             (int)getBounds().getWidth(), (int)getBounds().getHeight(), this);
    }

    public void setBackGroundImage(Image backGround) {
         this.backGround = backGround; 
    }

    private Image getBackGroundImage() {
         return backGround;    
    }

	
	
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == ret){
			this.setVisible(false);
			this.parent.returned();
		}
		else if (e.getSource() == ok){
			this.setVisible(false);
			try{  
				Class.forName("com.mysql.jdbc.Driver");  
				Connection con=DriverManager.getConnection(  
				"jdbc:mysql://localhost:3306/BSAdminUsers","root","0019119275");  
				Statement stmt=con.createStatement();  
				ResultSet rs=stmt.executeQuery("select * from admins where username=\""+username.getText().trim()+"\" and pass=\""+password.getText().trim()+"\"");  
				if(rs.next())
					this.parent.DBManage();
				else{
					this.parent.returned();
					JOptionPane.showMessageDialog(null, "Invalid username and password");
				}
				con.close();  
				}catch(Exception e1){ JOptionPane.showMessageDialog(null, e1);}
			
		}
	}

}
