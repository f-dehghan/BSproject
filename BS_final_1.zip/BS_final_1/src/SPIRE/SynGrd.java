package SPIRE;

import java.util.Vector;

public class SynGrd {

	Preprocess pre;

	Vector<Integer> c;
	Vector<double[]> prob;

	public Vector<Integer> getC() {
		return c;
	}

	public void setC(Vector<Integer> c) {
		this.c = c;
	}

	public SynGrd(String goal, Preprocess pre) {

		this.pre = pre;
		// c = new Integer[pre.count + 1];
		c = new Vector<>();
		this.prob = new Vector<>(pre.Pprob);

		if (goal.compareTo("permissiveness") == 0)
			perPrepare();// make ci's according to goal as permissiveness
		else
			prePrepare();// make ci's according to goal as precision


		updateProb();

		synGreedy();
		System.out.println("end");

	}

	// the main loop of the synGRD algorithm
	private void synGreedy() {

		while (!allValidate()) {
			int cls = 0;
			double maxDist = -1;
			for (int i = 0; i < pre.count + 1; i++) {
				if (c.contains(i)) {
					double temp = CDist(i);
					if (maxDist < temp) {
						maxDist = temp;
						cls = i;
					}
				}
			}
			Integer tempCls = candidateClsIn(cls);
			if (tempCls > -1) {
				for(int j = 0 ; j<c.size() ; j++){
					if(c.elementAt(j) == cls){
						c.set(j, tempCls);
					}
				}
			} else {
				tempCls = candidateClsOut(cls);
				for(int j = 0 ; j<c.size() ; j++){
					if(c.elementAt(j) == cls){
						c.set(j, tempCls);
					}
				}
			}
			updateProb();
//			printProb();
//			System.exit(0);
			}
	}


	private Integer candidateClsIn(int cls) {
		Vector<Integer> result = new Vector<>(c);
		Integer minCls = -1;
		double minDist = 10000;

		for (int i = 0; i < pre.count + 1; i++) {
			if (c.contains(i) && i != cls) {
				for (int j = 0; j < c.size(); j++) {
					if (c.elementAt(j) == cls) {
						result.set(j, i);
					}
				}
				Vector<Integer> temp = new Vector<>();
				for (int j = 0; j < result.size(); j++) {
					if (result.elementAt(j) == i) {
						temp.add(j);
					}
				}
				double[] newProb = computeProb(temp);
				double sum = 0;
				int flag = 1;
				for (int j = 0; j < newProb.length; j++) {
					if (newProb[j] > pre.policies.elementAt(j).Ubound
							|| newProb[j] < pre.policies.elementAt(j).Lbound) {
						flag = 0;
						break;
					} else {
						newProb[j] = Math.abs(newProb[j]
								- pre.policies.elementAt(j).Center);
						newProb[j] = Math.pow(newProb[j], 2);
						sum = sum + newProb[j];
					}
				}
				if (flag == 1) {
					sum = Math.sqrt(sum);
					if (sum < minDist) {
						minDist = sum;
						minCls = i;
					}
				}

			}
		}
		return minCls;
	}
	
	private Integer candidateClsOut(int cls) {
		Vector<Integer> result = new Vector<>(c);
		Integer minCls = -1;
		double minDist = 10000;

		for (int i = 0; i < pre.count + 1; i++) {
			if (c.contains(i) && i != cls) {
				for (int j = 0; j < c.size(); j++) {
					if (c.elementAt(j) == cls) {
						result.set(j, i);
					}
				}
				Vector<Integer> temp = new Vector<>();
				for (int j = 0; j < result.size(); j++) {
					if (result.elementAt(j) == i) {
						temp.add(j);
					}
				}
				double[] newProb = computeProb(temp);
				double sum = 0;
				for (int j = 0; j < newProb.length; j++) {
					if (newProb[j] < pre.policies.elementAt(j).Ubound
							&& newProb[j] > pre.policies.elementAt(j).Lbound) {
						newProb[j] = 0;
					} else {
						if (newProb[j] > pre.policies.elementAt(j).Ubound)
							newProb[j] = Math.abs(newProb[j]- pre.policies.elementAt(j).Ubound);
						if (newProb[j] < pre.policies.elementAt(j).Lbound)
							newProb[j] = Math.abs(newProb[j]- pre.policies.elementAt(j).Lbound);
					}
					newProb[j] = Math.pow(newProb[j], 2);
					sum = sum + newProb[j];
				}
				
				sum = Math.sqrt(sum);
				if (sum < minDist) {
					minDist = sum;
					minCls = i;
				}
				

			}
		}
		return minCls;
	}
	
	
	// return true if all the classes in the policy bounds
	private boolean allValidate() {
		for (int i = 0; i < prob.size(); i++) {
			for (int j = 0; j < prob.elementAt(i).length; j++) {
				if (prob.elementAt(i)[j] != -1 && (prob.elementAt(i)[j] > pre.policies.elementAt(j).Ubound
						|| prob.elementAt(i)[j] < pre.policies.elementAt(j).Lbound)) {
					return false;
				}
			}
		}

		return true;
	}

	// compute the class distance to the policy bounds
	private double CDist(int c) {

		double dist = 0;
		double[] tempD = new double[pre.policies.size()];
		double L, U, P;
		for (int i = 0; i < pre.policies.size(); i++) {
			U = pre.policies.elementAt(i).Ubound;
			L = pre.policies.elementAt(i).Lbound;
			P = prob.elementAt(c)[i];
			if (P > L && P < U) {
				tempD[i] = 0;
			} else {
				if (P < L)
					tempD[i] = Math.abs(L - P);
				else
					tempD[i] = Math.abs(U - P);
			}
		}

		for (int i = 0; i < tempD.length; i++) {
			dist = dist + ((double) Math.pow(tempD[i], 2));
		}
		dist = Math.sqrt(dist);
		return dist;
	}

	private void perPrepare() {
		for (int i = 0; i < pre.count + 1; i++)
			c.add(i);

	}

	private void prePrepare() {
		int share = -1;
		for (int i = 0; i < pre.Pprob.size(); i++) {
			int test = 0;
			for (int j = 0; j < pre.policies.size(); j++) {
				if (pre.Pprob.elementAt(i)[j] > pre.policies.elementAt(j).Ubound
						|| pre.Pprob.elementAt(i)[j] < pre.policies
								.elementAt(j).Lbound) {
					test = 1;
					break;
				}
			}
			if (test == 1) {
				if (share == -1) {
					share = i;
				}
				c.add(share);
			} else {
				c.add(i);
			}
		}

	}

	// update the prob vector for each change in output classes
	private void updateProb() {

		for (int i = 0; i < pre.count + 1; i++) {
			double[] result = new double[pre.policies.size()];
			if (c.contains(i)) {
				Vector<Integer> temp = new Vector<>();
				for (int j = 0; j < c.size(); j++) {
					if (c.elementAt(j) == i) {
						temp.add(j);
					}
				}
				// System.out.println("---" + temp.size());
				result = computeProb(temp);
			} else {
				for (int j = 0; j < pre.policies.size(); j++) {
					result[j] = -1;
				}
			}
			prob.set(i, result);
		}
	}

	private double[] computeProb(Vector<Integer> temp) {

		double[] result = new double[pre.policies.size()];
		int countO = 0;

		for (int i = 0; i < pre.outputs.size(); i++) {
			for (int j = 0; j < temp.size(); j++) {
				if (pre.outputs.elementAt(i)[temp.elementAt(j)] == 1) {
					countO++;
				}
			}
		}

		for (int i = 0; i < pre.policies.size(); i++) {
			int countSO = 0;
			for (int j = 0; j < pre.permutations.size(); j++) {
				if (((pre.permutations.elementAt(j))[pre.policies.elementAt(i).ID])
						.equals(pre.policies.elementAt(i).value)) {
					int flag = 0;
					for (int k = 0; k < temp.size(); k++) {
						if (pre.outputs.elementAt(j)[temp.elementAt(k)] == 1) {
							flag = 1;
							break;
						}
					}
					if (flag == 1) {
						countSO++;
					}
				}
			}
			result[i] = ((double) countSO) / countO;
		}
		return result;
	}
	
	
//	private void printProb(){
//		for (double[] d : prob) {
//		for (int i = 0; i < d.length; i++) {
//			System.out.print("   " + d[i]);
//		}
//		System.out.println(" ");
//	}
//
//	System.out.println("****************************");
//	
//		
//	}
}
