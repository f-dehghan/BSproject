package SPIRE;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JOptionPane;

public class FetchPolicy {

	String table;
	String col;

	private Vector<Policy> policies = new Vector<>();

	public FetchPolicy(String DB,String USER,String PASS,String table, String col) {

		this.col = col;
		this.table = table;

		connect(DB,USER,PASS);
		for (Policy v : getPolicies()) {
			System.out.println(v.ID + "  " + v.value + " " + v.Lbound + "  "
					+ v.Ubound);
		}
	}

	private void connect(String DB,String USER, String PASS) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/"+DB, USER, PASS);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt
					.executeQuery("select * from policy where tableName =\'"
							+ table + "\' and columnName=\'" + col + "\'");
			while (rs.next()) {
				getPolicies().addElement(new Policy(rs.getInt("PID"),col, rs
						.getString("Pvalue"), rs.getDouble("lb"), rs
						.getDouble("ub")));
			}
			con.close();
		} catch (Exception e1) {
			String[] s = e1.toString().trim().split(":");
			JOptionPane.showMessageDialog(null, s[1]);
		}

	}

	public Vector<Policy> getPolicies() {
		return policies;
	}

	public void setPolicies(Vector<Policy> policies) {
		this.policies = policies;
	}

//	public static void main(String[] args) {
//		new FetchPolicy("testT1", "ADDR");
//	}
}
