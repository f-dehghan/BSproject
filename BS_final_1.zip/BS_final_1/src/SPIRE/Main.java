package SPIRE;

public class Main {
	
	
	public static void main(String[] args) {
//		FetchSecret fs = new FetchSecret("testT1", "ADDR", "tehran");
//		FetchPolicy fp = new FetchPolicy("testT1", "ADDR");
//		Preprocess pre = new Preprocess(fs.getValues(), fs.getTotal(), fs.getValue(), fp.getPolicies());
//		new SynGrd("precision", pre);
		System.out.println("HIII");

	}

}
