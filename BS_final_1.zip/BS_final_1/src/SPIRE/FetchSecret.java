package SPIRE;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class FetchSecret {

	String table;
	String col;
	private String value;

	int result;
	private int total;
	private String[] values;

	public FetchSecret(String DB, String USER, String PASS, String Table, String col, String value) {

		this.setValue(value);
		this.table = Table;
		this.col = col;

		connect(DB,USER,PASS);

		System.out.println(getTotal() + "    " + result);
		for (int i = 0; i < getValues().length; i++)
			System.out.println(getValues()[i]);

	}

	private void connect(String DB,String USER,String PASS) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/"+DB, USER, PASS);
			Statement stmt = con.createStatement();
			Statement stmt2 = con.createStatement();
			Statement stmt3 = con.createStatement();

			ResultSet rs = stmt.executeQuery("select count(*) as result from "
					+ table + " where " + col + "=\'" + getValue() + "\'");
			ResultSet rs2 = stmt2.executeQuery("select count(*) as total from "
					+ table);
			ResultSet rs3 = stmt3.executeQuery("select " + col + " from "
					+ table + " where ID=1");

			if (rs2.next())
				setTotal(rs2.getInt("total") - 1);
			if (rs.next())
				result = rs.getInt("result");
			if (rs3.next()) {
				setValues((rs3.getString(col).trim().replaceAll(" +", ""))
						.split(","));

			}
			con.close();
		} catch (Exception e1) {
			String[] s = e1.toString().trim().split(":");
			JOptionPane.showMessageDialog(null, s[1]);
		}
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String[] getValues() {
		return values;
	}

	public void setValues(String[] values) {
		this.values = values;
	}

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}
	
	

//	public static void main(String[] args) {
//
//		new FetchSecret("testT1", "ADDR", "tehran");
//
//	}

}
