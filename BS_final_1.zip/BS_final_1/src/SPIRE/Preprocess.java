package SPIRE;

import java.util.Vector;

public class Preprocess {
	// Calculate the required probabilities and make the program matrix

	Vector<Object[]> permutations = new Vector<>();
	Vector<Integer[]> outputs = new Vector<>();

	Object[] values;
	int count;
	Object desire;
	Vector<Policy> policies = new Vector<>();

	double[] Oprob;
	Vector<double[]> Pprob = new Vector<>();
	
	public Preprocess(Object[] values, int count, Object desire,
			Vector<Policy> policies) {

		this.count = count;
		this.values = values;
		this.desire = desire;
		this.policies = policies;
		
		this.Oprob  = new double[count + 1];
		
		makeMatrix();
		computeOutputsProb();
		computePolicyProb();
	}


	private void makeMatrix() {
		createPermutations(values, values.length, count);
		createOutputs();
		System.out.println(permutations.size() + "********" + outputs.size());
		// for (int j = 0 ; j<permutations.size(); j++ ) {
		// for(int i = 0 ; i< (permutations.elementAt(j)).length ; i++)
		// System.out.print((permutations.elementAt(j))[i]);
		// for(int i =0 ; i < (outputs.elementAt(j)).length ; i++)
		// System.err.print(" "+(outputs.elementAt(j))[i]);
		// System.out.println("");
		// }
	}

	//compute the probability of P(Oi)
	private void computeOutputsProb() {
		for (int i = 0; i < count + 1; i++)
			Oprob[i] = 0;
		int total = outputs.size();
		for (int i = 0; i < outputs.size(); i++) {
			for (int j = 0; j < outputs.elementAt(i).length; j++) {
				if ((outputs.elementAt(i))[j] == 1) {
					Oprob[j]++;
				}
			}
		}
		for (int i = 0; i < count + 1; i++) {
			System.out.println(Oprob[i] + " ");
			Oprob[i] = Oprob[i] / total;
		}
		return;
	}

	
	//compute the probability of P(Si|oi)
	private void computePolicyProb() {
		for(int i = 0 ; i<count+1 ; i++){
			double[] temp = new double[policies.size()];
			for(int j =0 ; j < policies.size() ; j++){
				double sum  = 0  ;
				for (int k = 0 ; k<permutations.size();k++) {
					if(((permutations.elementAt(k))[policies.elementAt(j).ID]).equals(policies.elementAt(j).value) &&
							outputs.elementAt(k)[i]==1){
						sum++;
					}
				}
				temp[j] = (sum/permutations.size())/Oprob[i];
//				System.out.println("###"+temp[j]+"  "+policies.elementAt(j).Lbound);
			}
			Pprob.addElement(temp);
		}
	}

	
	// create all the possible permutations over the values of the column
	private void createPermutations(Object[] array, int Choice, int Dlength) {
		PermuteCallback callback = new PermuteCallback() {
			@Override
			public void handle(Object[] snapshot) {
				permutations.add(snapshot);
			}
		};
		permute(array, Dlength, callback);

	}

	public interface PermuteCallback {
		public void handle(Object[] snapshot);
	};

	public void permute(Object[] a, int k, PermuteCallback callback) {
		int n = a.length;

		int[] indexes = new int[k];
		int total = (int) Math.pow(n, k);

		while (total-- > 0) {
			Object[] snapshot = new Object[k];
			for (int i = 0; i < k; i++) {
				snapshot[i] = a[indexes[i]];
			}
			callback.handle(snapshot);

			for (int i = 0; i < k; i++) {
				if (indexes[i] >= n - 1) {
					indexes[i] = 0;
				} else {
					indexes[i]++;
					break;
				}
			}
		}
	}

	// create the output part of the matrix for possible permutations
	private void createOutputs() {
		for (int i = 0; i < permutations.size(); i++) {
			Integer[] output = new Integer[count + 1];
			int sum = 0;
			for (Object o : permutations.elementAt(i)) {
				if (desire.equals(o)) {
					sum++;
				}
			}
			for (int j = 0; j < count + 1; j++) {
				if (j == sum)
					output[j] = 1;
				else
					output[j] = 0;
			}
			this.outputs.addElement(output);
		}
	}
}
