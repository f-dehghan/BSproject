package SPIRE;

public class Policy {

	// Each policy of the column in the table is defined on the people with a
	// belief bound of the attacker belief
	int ID;
	String col;
	Object value;
	double Lbound;
	double Ubound;
	double Center;

	public Policy(int ID, String col, Object value, double Lbound, double Ubound) {
		this.ID = ID;
		this.col = col;
		this.value = value;
		this.Lbound = Lbound;
		this.Ubound = Ubound;
		this.Center = (Ubound + Lbound) / 2;
	}
}
