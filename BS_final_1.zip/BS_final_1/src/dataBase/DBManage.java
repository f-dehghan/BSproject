package dataBase;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Main.Main;

public class DBManage extends JPanel implements ActionListener {
	private static final long serialVersionUID = 1L;
	
	Main parent;
	Image backGround;
	JButton ret;
	JButton okAdd;
	JButton okRem;
	
	JLabel addL;
	JLabel remL;
	JLabel DBName1L;
	JLabel DBName2L;
	JLabel userL;
	JLabel passL;
	
	JTextField DBname1;
	JTextField username;
	JTextField password;
	
	JComboBox<String> DBname2;

	public DBManage(Main parent) {
		
		this.setLayout(null);
		
		this.parent = parent;
		
		//ADD PARTITION
		addL= new JLabel("Add New DB");
		addL.setFont(new Font("Times New Roman" , 30,30));
		addL.setForeground(Color.WHITE);
		addL.setSize(300,50);
		addL.setLocation(50, 50);
		this.add(addL);
		
		DBName1L= new JLabel("DB name:");
		DBName1L.setFont(new Font("Times New Roman" , 20,20));
		DBName1L.setForeground(Color.WHITE);
		DBName1L.setSize(150,30);
		DBName1L.setLocation(100, 120);
		this.add(DBName1L);
		
		userL = new JLabel("user name:");
		userL.setFont(new Font("Times New Roman" , 20,20));
		userL.setForeground(Color.WHITE);
		userL.setSize(150,30);
		userL.setLocation(100, 170);
		this.add(userL);
		
		
		passL = new JLabel("password:");
		passL.setFont(new Font("Times New Roman" , 20,20));
		passL.setForeground(Color.WHITE);
		passL.setSize(150,30);
		passL.setLocation(100, 220);
		this.add(passL);
		
		
		DBname1 = new JTextField();
		DBname1.setFont(new Font("Times New Roman" , 20,20));
		DBname1.setSize(200,40);
		DBname1.setEditable(true);
		DBname1.setLocation(300, 120);
		this.add(DBname1);
		
		username = new JTextField();
		username.setFont(new Font("Times New Roman" , 20,20));
		username.setSize(200,40);
		username.setEditable(true);
		username.setLocation(300, 170);
		this.add(username);
		
		
		password = new JTextField();
		password.setFont(new Font("Times New Roman" , 20,20));
		password.setSize(200,40);
		password.setEditable(true);
		password.setLocation(300, 220);
		this.add(password);
		
		okAdd = new JButton("OK");
		okAdd.setFont(new Font("Times New Roman" , 20,20));
        okAdd.setIcon(new ImageIcon("../welcome/ok_button.png"));
		okAdd.setSize(100,50);
		okAdd.setLocation(600, 220);
		okAdd.addActionListener(this);
		this.add(okAdd);
		
		
		//REMOVE PARTITION
		
		remL= new JLabel("Remove A DB");
		remL.setFont(new Font("Times New Roman" , 30,30));
		remL.setForeground(Color.WHITE);
		remL.setSize(300,50);
		remL.setLocation(50, 300);
		this.add(remL);
		
		DBName2L= new JLabel("DB name:");
		DBName2L.setFont(new Font("Times New Roman" , 20,20));
		DBName2L.setForeground(Color.WHITE);
		DBName2L.setSize(150,30);
		DBName2L.setLocation(100, 400);
		this.add(DBName2L);
		
		DBname2 = new JComboBox<String>();
		DBname2.setSize(new Dimension(200,40));
		DBname2.setLocation(300, 400);
		updateList();
		this.add(DBname2);
		
		okRem = new JButton("OK");
		okRem.setFont(new Font("Times New Roman" , 20,20));
		okRem.setIcon(new ImageIcon("../welcome/ok_button.png"));
		okRem.setSize(100,50);
		okRem.setLocation(600, 400);
		okRem.addActionListener(this);
		this.add(okRem);
		
		ret = new JButton("return");
		ret.setFont(new Font("Times New Roman" , 30,30));
        ret.setIcon(new ImageIcon("../welcome/ret_button.png"));
		ret.setSize(200,50);
		ret.setLocation(50, 500);
		ret.addActionListener(this);
		this.add(ret);
		
        this.setBackGroundImage(new ImageIcon("../welcome/Main_back.jpg").getImage());

	}
	

    @Override
   protected void paintComponent(Graphics g) {

         // get the size of this panel (which is the size of the applet),
         // and draw the image
   	 super.paintComponent(g);
         g.drawImage(getBackGroundImage(), 0, 0,
             (int)getBounds().getWidth(), (int)getBounds().getHeight(), this);
    }

    public void setBackGroundImage(Image backGround) {
         this.backGround = backGround; 
    }

    private Image getBackGroundImage() {
         return backGround;    
    }

	
	
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == ret){
			this.setVisible(false);
			this.parent.returned();
		}
		else if (e.getSource() == okAdd){
			String db = DBname1.getText().trim();
			String user = username.getText().trim();
			String pass = password.getText().trim();
			try{  
				Class.forName("com.mysql.jdbc.Driver");  
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+db,user,pass);  
				con.close();
				addToDBs();
				}catch(Exception e1){ 
					String[] s = e1.toString().trim().split(":");
					JOptionPane.showMessageDialog(null, s[1]);}			
			
		}
		else if (e.getSource() == okRem){
			String db = DBname2.getSelectedItem().toString().trim();
			try{  
				Class.forName("com.mysql.jdbc.Driver");  
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/BSAdminUsers","root","0019119275");
				Statement stmt=con.createStatement();  
				ResultSet rs=stmt.executeQuery("select * from DBs where DB_name=\'"+db+"\'");  
				if(rs.next())
					removeFromDBs();
				else{
					JOptionPane.showMessageDialog(null, "This DB doesn't exist!!");
				}
				con.close();
				}catch(Exception e1){ 
					String[] s = e1.toString().trim().split(":");
					JOptionPane.showMessageDialog(null, s[1]);}			
				
		}
	}
	
	private void addToDBs(){
		String db = DBname1.getText().trim();
		String user = username.getText().trim();
		String pass = password.getText().trim();
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/BSAdminUsers","root","0019119275");  
			Statement stmt=con.createStatement();  
			stmt.executeUpdate("insert into DBs values (\'"+db+"\',\'"+user+"\',\'"+pass+"\')");  
			con.close();  
			updateList();
			JOptionPane.showMessageDialog(null, "DataBase added successfully.");
			}catch(Exception e1){
				String[] s = e1.toString().trim().split(":");
				JOptionPane.showMessageDialog(null, s[1]);}
	}
	
	private void removeFromDBs(){
		String db = DBname2.getSelectedItem().toString().trim();
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/BSAdminUsers","root","0019119275");  
			Statement stmt=con.createStatement();  
			stmt.executeUpdate("delete from DBs where DB_name=\'"+db+"\'");  
			con.close(); 
			updateList();
			JOptionPane.showMessageDialog(null, "DataBase removed successfully.");
			}catch(Exception e1){
				String[] s = e1.toString().trim().split(":");
				JOptionPane.showMessageDialog(null, s[1]);}
	}
	
	private void updateList(){
		Vector<String> list = new Vector<String>();
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/BSAdminUsers","root","0019119275");  
			Statement stmt=con.createStatement();  
			ResultSet rs=stmt.executeQuery("select DB_name from DBs");  
			while(rs.next())
				list.add(rs.getString(1));
			con.close();  
			DBname2.removeAllItems();
			for(String v: list)
				DBname2.addItem(v);
			//JOptionPane.showMessageDialog(null, "DataBase removed successfully.");
			}catch(Exception e1){
				String[] s = e1.toString().trim().split(":");
				JOptionPane.showMessageDialog(null, s[1]);}
	}

}
